// "use server"

// import { prisma } from "@/lib/db"

// import { revalidatePath } from "next/cache"

// interface Params {
//     userId: string,
//     username: string,
//     name: string,
//     bio: string,
//     image: string,
//     path: string
// }

// export async function updateUser({
//     userId,
//     username,
//     name,
//     bio,
//     image,
//     path
// }: Params): Promise<void>{

//     try {
//         // const post = await prisma.user.findUnique({ where: { id:  userId } })
    
//         // if( ! post ) 
//         //     return new Response("Post Not Found~", { status: 404 })
    
//         await prisma.user.upsert({
//             where: {
//                 id: userId
//             },
//             update: {
//                 username: username.toLowerCase(),
//                 name,
//                 bio,
//                 image,
//                 onboarded: true,
//                 email: username+'@acp.org.np'
//             },
//             create: {
//                 id: userId,
//                 username: username.toLowerCase(),
//                 name,
//                 bio,
//                 image,
//                 onboarded: true,
//                 email: username+'@acp.org.np'
//             }
//         })
    
//         if (path === '/profile/edit') {
//             revalidatePath(path)
//         }

//     } catch (error: any) {
//         throw new Error(`Failed to update user: ${error.message}`)
//     }
// }


// export async function fetchUser(userId: string) {
    
//     try {
//         return await prisma.user.findUnique({
//             where: {
//                 id: userId
//             }
//         })
//     } catch (error) {
//         throw new Error()
//     }

// }

// export async function searchUsers({
//     userId,
//     searchString = "",
//     pageNumber = 1,
//     pageSize = 20,
//     sortBy = "desc"
// }: {
//     userId: string
//     searchString?: string,
//     pageNumber?: number,
//     pageSize?: number,
//     sortBy?: string
// }){

//     try {

//         const skipAmount = (pageNumber - 1) * pageSize;

//         const regex = new RegExp(searchString, "i")

//         let query: any = {
//             where: {
//                 NOT: {
//                     id: userId
//                 },
//             },
//             orderBy: {
//                 name: sortBy
//             },
//             skip: skipAmount,
//             take: pageSize,
//         }

//         if (searchString.trim() !== '') {
            
//             query.where.OR = [
//                 { username: { $regex: regex } },
//                 { name: {$regex: regex} }
//             ]

//         }

//         const data = await prisma.user.findMany(query)

//         const totalCount = await prisma.user.findMany();

//         const isNext = totalCount.length > skipAmount + data.length

//         return {data, isNext}

//     } catch (error: any) {
//         throw new Error(`Failed to update user: ${error.message}`)
//     }
// }